'use strict';
// const mediaStreamConstraints={    //create an object of media stream for all the things which you need
//     video:true
// };

let localStream;
let penColor='black'
// function gotLocalMediaStream(mediaStream)
// {
//     const localVideo=document.querySelector('video')
//     localStream=mediaStream
//     localVideo.srcObject=mediaStream
//     localVideo.play()
// }

// // Handles error by logging a message to the console with the error message.
// function handleLocalMediaStreamError(error) {
//     console.log('navigator.getUserMedia error: ', error);
//   }


// navigator.mediaDevices.getUserMedia(mediaStreamConstraints)    //returns a promise which is then returned to the device 
// .then(gotLocalMediaStream).catch(handleLocalMediaStreamError);


let h3
function draw(xCoor,yCoor) {
    console.log(xCoor,yCoor)
    context.beginPath();
    context.moveTo(lastX, lastY);
    context.lineTo(xCoor, yCoor);
    context.strokeStyle = penColor;
    context.lineWidth = 2;
    context.stroke();
    [lastX, lastY] = [xCoor, yCoor];
}

// function updateFrames() {
//     h3 = document.querySelector('h3');
//     while (h3.firstChild) {
//         h3.removeChild(h3.firstChild); // Remove all existing child nodes
//     }
//     const para = document.createElement('p');
//     para.textContent = localStream.getVideoTracks()[0]['stats']['deliveredFrames'] + "";
//     h3.appendChild(para);
// }

// setInterval(updateFrames, 10);
let rc
function connect(){
let offerArea=document.querySelector(".setDesc")

let offer=offerArea.value
let ans
let xCoor
let yCoor
let lx=0
let ly=0
const iceConfiguration = {
    iceServers: [
        {
            urls: [
                "STUN:stun.f.haeder.net:3478"
            ]
        },
        {
            urls: [
                "turn:13.250.13.83:3478?transport=udp"
            ],
            "username": "YzYNCouZM1mhqhmseWk6",
            "credential": "YzYNCouZM1mhqhmseWk6"
        }
    ]
};
rc=new RTCPeerConnection(iceConfiguration)
rc.ondatachannel = e=>{
    rc.dc=e.channel
    rc.dc.onmessage = e=>{
        console.log("Coordinates from client: "+JSON.parse(e.data))
        xCoor=JSON.parse(e.data)['xCoor']
        yCoor=JSON.parse(e.data)['yCoor']
        lx=JSON.parse(e.data)['lx']
        ly=JSON.parse(e.data)['ly']
        penColor=JSON.parse(e.data)['color']
        console.log(lx,ly,penColor)
        draw(xCoor,yCoor,lx,ly);
    }
    rc.dc.onopen=e=>console.log("connection opened!!!")
}
rc.setRemoteDescription(JSON.parse(offer)).then(a=>console.log("offer set"))
}
let identity
function createAnswer(){
    let answerArea=document.querySelector(".createDesc")
    let ans
    rc.createAnswer().then(
        a=>rc.setLocalDescription(a)
    
    ).then(a=>console.log("Asnwer created"))
    rc.onicecandidate= e=>{
        // console.log("new ice candidate reprinting SDP" +JSON.stringify(rc.localDescription))
        ans=JSON.stringify(rc.localDescription)
        answerArea.textContent=ans
        identity=ans
    }
}


function sendMessage(){
    const msg=document.querySelector(".writeMsg")
    const text=msg.value
    rc.dc.send(text)
}

let socket
function connectToServer(){
    socket = new WebSocket('ws://192.168.52.128:8080');
}

const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");

let lastX = 0;
let lastY = 0;

function draw(xCoor,yCoor,lx,ly) {
    // console.log(typeof lx,typeof ly)
    context.beginPath();
    if(lastX!=xCoor+1 || lastX!=xCoor-1  && lastY!=yCoor)
    {
        lastX=xCoor
        lastY=yCoor
    }
    context.moveTo(lx, ly);
    context.lineTo(xCoor, yCoor);
    context.strokeStyle = penColor;
    context.lineWidth = 2;
    context.stroke();
    [lastX, lastY] = [xCoor, yCoor];
}

// function draw(e) {
//     if (!isDrawing) return;
    
//     context.moveTo(lastX, lastY);
//     context.lineTo(e.offsetX, e.offsetY);
//     context.strokeStyle = "black";
//     context.lineWidth = 2;
//     context.stroke();
//     [lastX, lastY] = [e.offsetX, e.offsetY];
//     console.log({xCoor:e.offsetX,yCoor:e.offsetY})
//     dc.send(JSON.stringify({xCoor:e.offsetX,yCoor:e.offsetY}))
// }