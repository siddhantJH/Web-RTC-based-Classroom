// const lc=new RTCPeerConnection()
// const dc=lc.createDataChannel("channel")
// dc.onmessage=e=>console.log(e.data)
// e=>console.log(e.data)
// dc.onopen=e=>console.log("Connection open")
// e=>console.log("Connection open")
// //next we need to create an offer now everythime i get ice candidate we need to print the sdp 
// lc.onicecandidate = e=> console.log("ice candidate reprinting SDP"+JSON.stringify(lc.localDescription))
// e=> console.log("ice candidate reprinting SDP"+JSON.stringify(lc.localDescription))
// //next we need to create a offer
// lc.createOffer().then(o=>lc.setLocalDescription(o)).then(a=>console.log("Set successfully"))//it returns a promise so when we create a offer set it as a 
// Promise {<pending>}
// VM3710:11 Set successfully
// 2VM3710:8 ice candidate reprinting SDP{"type":"offer","sdp":"v=0\r\no=- 4268910497987687302 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS\r\nm=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\nc=IN IP4 0.0.0.0\r\na=candidate:1419147089 1 udp 2113937151 17ac89e9-55fb-45f8-83d5-a00f9b897016.local 56971 typ host generation 0 network-cost 999\r\na=ice-ufrag:GMCW\r\na=ice-pwd:weaKXpSFDhO/iGpwxgixAPP1\r\na=ice-options:trickle\r\na=fingerprint:sha-256 6F:89:A9:59:C3:A6:15:8C:4E:3E:36:09:19:CC:7F:ED:81:EF:E6:E0:D2:02:86:7B:E3:2E:E7:4F:C0:71:12:16\r\na=setup:actpass\r\na=mid:0\r\na=sctp-port:5000\r\na=max-message-size:262144\r\n"}
// const ans={"type":"answer","sdp":"v=0\r\no=- 2400445796204620823 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS\r\nm=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\nc=IN IP4 0.0.0.0\r\na=candidate:841199578 1 udp 2113937151 e730fffb-1d62-44b2-aa94-53df8e4df0d8.local 64195 typ host generation 0 network-cost 999\r\na=ice-ufrag:DqPK\r\na=ice-pwd:fkU1UqViyRoiG9WYZqQ6DR7w\r\na=ice-options:trickle\r\na=fingerprint:sha-256 15:ED:B9:78:ED:3F:FA:21:77:75:C1:04:2F:E6:62:A1:60:B6:1D:F3:DE:BB:83:EA:D7:2D:40:C6:B9:63:2D:03\r\na=setup:active\r\na=mid:0\r\na=sctp-port:5000\r\na=max-message-size:262144\r\n"}
// undefined



//perform this after we get the answer from receiver side in line 11 in receiver.js
// lc.setRemoteDescription(answer)
// VM3817:1 Uncaught ReferenceError: answer is not defined
//     at <anonymous>:1:25
// (anonymous) @ VM3817:1
// lc.setRemoteDescription(ans)
// Promise {<pending>}
// VM3710:5 Connection open
// dc.send("hello brother")   //to send to recveiver 
// undefined
// VM3710:3 chootlc






// <!-- 

// const lc=new RTCPeerConnection()
// const dc=lc.createDataChannel("channel")
// dc.onmessage=e=>console.log(e.data)
// e=>console.log(e.data)
// dc.onopen=e=>console.log("Connection open")
// e=>console.log("Connection open")
// //next we need to create an offer now everythime i get ice candidate we need to print the sdp 
// lc.onicecandidate = e=> console.log("ice candidate reprinting SDP"+JSON.stringify(lc.localDescription))
// e=> console.log("ice candidate reprinting SDP"+JSON.stringify(lc.localDescription))
// //next we need to create a offer
// lc.createOffer().then(o=>lc.setLocalDescription(o)).then(a=>console.log("Set successfully"))//it returns a promise so when we create a offer set it as a 
// Promise {<pending>} -->



// <!-- we get the ice -->


// <!-- this is json object which we need to keep with -->
// <!-- ice candidate reprinting SDP{"type":"offer","sdp":"v=0\r\no=- 4268910497987687302 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS\r\nm=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\nc=IN IP4 0.0.0.0\r\na=candidate:1419147089 1 udp 2113937151 17ac89e9-55fb-45f8-83d5-a00f9b897016.local 56971 typ host generation 0 network-cost 999\r\na=ice-ufrag:GMCW\r\na=ice-pwd:weaKXpSFDhO/iGpwxgixAPP1\r\na=ice-options:trickle\r\na=fingerprint:sha-256 6F:89:A9:59:C3:A6:15:8C:4E:3E:36:09:19:CC:7F:ED:81:EF:E6:E0:D2:02:86:7B:E3:2E:E7:4F:C0:71:12:16\r\na=setup:actpass\r\na=mid:0\r\na=sctp-port:5000\r\na=max-message-size:262144\r\n"} -->
