// const accID="2121"
// let accID2="2121"
// accID=21 //gives an error 
// accID2=21 //does'nt give an error 
// console.log(accID2)

// var num=21
// function add()
// {
//     var num=22
// }
// console.log(num) //this have problems with scope


// account="21" //we could also assign value to account withing defingin its type 
// console.log(account)

// "use strict" //it treats all js as a newer version
// console.log(3+3)
// console.log("siddhant") 

// let num="21"
// console.log(typeof num)  //used to find the datatype of the number 



// let score=33
// console.log(typeof score)

// let score1=""
// // console.log(typeof score1)


// // //suppose we have received the value in a string now we want to perfrom the converstion from string to number 
// // let str_to_num=Number(score1)
// // console.log(str_to_num) 


// let isLoggedin=" "
// let booleanIsLoggedIn=Boolean(isLoggedin)
// console.log(booleanIsLoggedIn)


// console.log("2"==2)

// const myFun=function(){   //only function is assigned to the variable we need to call it as well
//     console.log("Hello")
// }

// myFun()




// const d=new Date()
// console.log(d.toString())
// console.log(d.toLocaleString())
// console.log(typeof d)

// let myCreatedDate1=new Date("2023-01-14")   //setting up custom date like this 
// console.log(myCreatedDate1.toLocaleString())


// let myTimeStamp=Date.now()
// console.log(myTimeStamp)       
// //to convert it to time we do this 
// console.log(myCreatedDate1.getTime()) //convert date to millisec

// let newDate=new Date()
// console.log(newDate.getMonth()+1)
// console.log(newDate.getDay());

//objects can be declareed in two ways literals and constructore 
//constructor(singleton banega)

//Object literat ways 
//stored as keys and values keys apne app me string ki tarah hai
//There is special data type called as symbol now lets declare a symbol 
// const mySym=Symbol("key 1") //declared a symbol , now if we want to use this symbol as the key we can't d it directly 
//                             //we need to use something as this square bracket 
// const JsUser = {name:"Siddhant",age:18,location:"Jaipur",[mySym]:"mykey1",email:"rohan@gmail",isLoggedIn:false,lastLogin:["Mon","Tue"],"full name":"Siddhant Jha"}  

// //In Order to access the object we could use square brackets or dot pperator 
// console.log(JsUser.email)
// console.log(JsUser["email"]) 
// console.log(JsUser.mySym)  //it prints undefined , but still it is not being interpreted as a symbol
// console.log(JsUser[mySym]) //if we want to use it as a symbol we need to use it as a square bracket when mentioning it as a key not by dot , dot gives the string 

// //in above object we won'nt be able to access the full name usind dot operator so we much use dot opeartror, so we mush use square brackets 
// console.log(JsUser["full name"])


// //to change the vlaues 
// JsUser.email="siddhant23098"
// console.log(JsUser)

// //if we want to freez the object 
// // Object.freeze(jsUser) //now if we try to change it the changes won't get propagated into the main object 


// JsUser.greeting = function()   //adding new attributes into the greeting function that prints strign and name 
// {
//     console.log("Hello js user"); 
//     console.log(`${this.name}`)   //if i want to refernce any name present inside the JsUser object we use this way 
// }                                  //use this to refernce same object ,this referes to the current context of the object 

// console.log(JsUser.greeting) //get function reference 
// console.log(JsUser.greeting()) //we get undefined, one execution is done autimatically

// console.log(JsUser)




// //Destructuring of an object 
// const course={
//     coursename:"Js in hindi",
//     price:"999",
//     courseInst:"Sidd"
// }
// //destructufin properties and bind them to a variable 

// console.log(course.courseInst) //bar bar . use karna is not ckear
// const {price} = course   //keyname:Inst is my name custom 
// // console.log(courseInst)  //destructuring object 
// // console.log(Inst)
// console.log(price)\





//global scope
// let a=300
// //scope is defined like this 
// if(true){   //variable is declare inside if so the work of this variabel is within this 
//     //block scope
//     let a=10 
//     const b =20
//     var c=30
//     console.log("Inner",a)
// }
// //now if a scope of a variable can be accessed here than it is a problem


// //now there is no problem with a and b as thet don't get printed but c is printing the value so it is the problem 
// // console.log(a);
// // console.log(b);
// //problem can be solved by usig the let , so var and no var is usually avoidable 
// //so if some programmer comes and declare the variable with same name so this problem might come 
// console.log(c)  

// //now if we try to print let inside and outside we would get different value due to block and global scope 
// console.log("Outer",a)


// //If we go in console than global scope is different and in node it is different 


//arrow function

//es6 came in arrow function and used in this keyword 

// const User={
//     username:"siddhant", //for current context the username is siddhant 
//     price:999,
//     welcome :function()
//     {
//         console.log(`Welcome to website ${this.username}`) //when we want to refer to current context(object) we refer only this object 
//         console.log(this)
//     }
// }

// //This referes current context 
// console.log(User.username="Siddhant")
// console.log(User)


// //To call a function inside the object use . notation 
// User.welcome()
// User.username="rohan" //this is changed and value is not harded coded and context is changed here
// console.log(User)
// console.log(this)  //in node enviorment when you are in node then this referes to empty parenthesis
// //however inside console in browser it will print windows , browser ke ander jo object hai vo window object hai 
// //now what if someone comes and change the username the context changes 



//-----------------Arrow--------------------

// function Chai()
// {
//     let username="Rohan"
//     console.log(this)  //now if we try to print the this inside a function inside the node env, than we can say that we will see the Chai()
//     console.log(this.username) //won't work inside the function
// }
// Chai() 





// const chai=function(){
//     let username="Rohan"
//     console.log(username)
// }
// chai()





//arrow function 

//es6 came in arrow function and used in this keyword 

// const User={
//     username:"siddhant", //for current context the username is siddhant 
//     price:999,
//     welcome :function()
//     {
//         console.log(`Welcome to website ${this.username}`) //when we want to refer to current context(object) we refer only this object 
//         console.log(this)
//     }
// }

// //This referes current context 
// console.log(User.username="Siddhant")
// console.log(User)


// //To call a function inside the object use . notation 
// User.welcome()
// User.username="rohan" //this is changed and value is not harded coded and context is changed here
// console.log(User)
// console.log(this)  //in node enviorment when you are in node then this referes to empty parenthesis
//however inside console in browser it will print windows , browser ke ander jo object hai vo window object hai 
//now what if someone comes and change the username the context changes 



//-----------------Arrow--------------------

// function Chai()
// {
//     let username="Rohan"
//     console.log(this)  //now if we try to print the this inside a function inside the node env, than we can say that we will see the Chai()
//     console.log(this.username) //won't work inside the function
// }
// Chai() 





// const chai=function(){
//     let username="Rohan"
//     console.log(username)
// }
// chai()





// // arrow function 

// const chai = ()=>{
//     let username="Siddhant"
//     console.log(this.username)
// }
// chai()

// // // can hold this inside a variable 
// const numone=(num1,num2)=>{
// return num1+num2
// }
// const numtwo=(num1,num2) => (num1+num2)
// // //In curly braces return must be used while in case of parenthesis no return is used 


// console.log(numone(10,20))
// console.log(numtwo(10,200))

// const numtwo2=(num1,num2) => (num1+num2)


// console.log(numtwo2(5,5))

// const greetings="Hello world!"
// for (const greet of greetings)
// {
// console.log(`Each car is ${greet}`)
// }
// const map=new Map()//stores only unique values
// map.set('IN',"India")
// map.set('USA',"United stated of america")
// console.log(map)

// const programming=["cpp","java","ruby"]
// for (const key in programming)
// {
//     console.log(key)  //we get the keys of the array and this key is the index 
//     console.log(programming[key])
// }



// const coding=["java","python","cpp","ruby"]
// const value = coding.forEach((item)=>{  //lopping through the object and at the same tine storing the values in the variabel 
//         console.log(item)   
//         return item//for each does'nt return any value 
// })

// console.log(value)



// const value1=coding.filter((item)=>{   //filters and keept the returned value on a list 
// return item
// })

// console.log(value1)


// const value2=coding.map((item)=>{
// return item+"gandu"
// })
// console.log(value2)   //map modifies the array and store the modified one in a different array 