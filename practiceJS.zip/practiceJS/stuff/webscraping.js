// const promiseOne = new Promise((resolve,reject)=>{
//     //Do an async task like DB calls nw calls etc
//     setTimeout(function(){
//         console.log('Async task is complete')
//         resolve()  
//     },1000) //what does resolve and reject do ??
//     //now we have createtd the promise now we need to consume it as well 
//     // console.log(promiseOne)
// }) 


// promiseOne.then(()=>{
//     console.log("Promise consumed")
// })



// const promisefour=new Promise(function(resolve,reject){
//     setTimeout(function(){
//         let error=true//suppose whatever we did failed
//         if(!error){
//             resolve({username:"sidd",pass:"123"})
//         }else{
//             reject('received from reject else part of promise') //when our task fails we need to pass error as well 
//         }
//     },1000)
// })

// promisefour.then((user)=>{ 
//     console.log(user)    //here we will get the response we need to pass it downward if we want to work on that 
//     return user.username //suppose we have recveived the user object but now we only want to deal with the username so we can pass the username and receove it in another cahained then()
// }).then((username)=>{
//     console.log(username)
// }).catch(function(error){
// console.log("Ye catch wala reject se call hoga",error)
// }).finally(function(){ //this will always execute , it is used for cleaning purpose
// console.log("promise is either resolved or rejected")
// })


//promise future me hone wali aik chiz hai 
//zaruri nai hai ki hamesha aap usko then catch se handle kare 
//async await se bhi kar sakte hai 

//thodi der wait karta hai kam hone ka ho jata hai tabhi continute karta hai , only dis is 
// async function consumePromiseFive(){
//     // const res= await promiseFive //jo bhi resolve hoke aae yaha milega ye promise aik eventual completiton object 
//     // console.log(res)   //agar isme error aa sakti hai to isme aapki error handle karna hoga to puri chiz ko try catch me kar dijiye 
//                         //kyoki aapka ye wala code reject error code ke return type ko handle nahi kar sakta
//     try{
//         const res= await promiseFive  
//         console.log(res)
//     }catch(error){
//         console.log(error);
//     }
// }
// //promise is something which happens in the future it is not necessary that you always need to handle it using the .then() and catch() function


// consumePromiseFive()

//api ket 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
const { Configuration, OpenAIApi } = require("openai");

const configuration = new Configuration({
  apiKey: "your-api-key-here", // Replace with your actual OpenAI API key
});
const openai = new OpenAIApi(configuration);

async function main() {
  try {
    const completion = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [{ role: "system", content: "You are a helpful assistant." }]
    });

    console.log(completion.data.choices[0].message.content);
  } catch (error) {
    console.error("Error:", error);
  }
}

main();
