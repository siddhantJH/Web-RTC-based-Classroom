'use strict';

// const mediaStreamConstraints = {
//     video: true
// };

// let localStream;

// function gotLocalMediaStream(mediaStream) {
//     const localVideo = document.querySelector('video');
//     localStream = mediaStream;
//     localVideo.srcObject = mediaStream;
//     localVideo.play();
// }

// function handleLocalMediaStreamError(error) {
//     console.log('navigator.getUserMedia error: ', error);
// }

// let h3;
// let para;
// function updateFrames() {
//     h3 = document.querySelector('h3');
//     while (h3.firstChild) {
//         h3.removeChild(h3.firstChild); // Remove all existing child nodes
//     }
//     para = document.createElement('p');
//     para.textContent = localStream.getVideoTracks()[0]['stats']['deliveredFrames'] + '';
//     h3.appendChild(para);
// }

// setInterval(updateFrames, 10);

let lc;
let dc;
let final;
let iceCandidate;
let penColor='black';
let isErasor;
// Select all color options
const colorOptions = document.querySelectorAll(".color-option");

// Loop through each color option and add a click event listener
colorOptions.forEach(colorOption => {
    colorOption.addEventListener("click", (e) => {
        console.log(e.target['classList'][1])
        penColor=e.target['classList'][1]
    });
});


const iceConfiguration = {
    iceServers: [
        {
            urls: [
                'STUN:stun.f.haeder.net:3478'
            ]
        },
        {
            urls: [
                'turn:13.250.13.83:3478?transport=udp'
            ],
            'username': 'YzYNCouZM1mhqhmseWk6',
            'credential': 'YzYNCouZM1mhqhmseWk6'
        }
    ]
};

function createSDP() {
    lc = new RTCPeerConnection(iceConfiguration);
    dc = lc.createDataChannel('channel');
    dc.onopen = e => console.log('Connection Opened');
    dc.onmessage = e => console.log(e.data);
    lc.onicecandidate = e => {
        console.log('ice candidate reprinting SDP' + JSON.stringify(lc.localDescription));
        iceCandidate = JSON.stringify(lc.localDescription);
        const sdpoffer = document.querySelector('.createDesc');
        sdpoffer.innerHTML = iceCandidate;
    };

    lc.createOffer()
        .then(o => lc.setLocalDescription(o))
        .then(() => {
            final = JSON.stringify(lc.localDescription);
            console.log('Final SDP Offer: ', final); // Log final SDP offer
            const sdpoffer = document.querySelector('.createDesc');
            sdpoffer.innerHTML = final;
            subscribe(); // Call subscribe() after setting localDescription
        })
        .catch(error => console.error('Error creating SDP offer: ', error));

    setTimeout(subscribe(), 2000);
}

function setAnswer() {
    const received = document.querySelector('.setDesc');
    const ans = received.value;
    lc.setRemoteDescription(JSON.parse(ans));
}

function sendMessage() {
    const msg = document.querySelector('.writeMsg');
    const text = msg.value;
    dc.send(text);
}

let socket;
function connectToServer() {
    socket = new WebSocket('ws://192.168.52.128:8080');
}

function subscribe() {
    socket.send(iceCandidate);
}

const canvas = document.getElementById('canvas');
const context = canvas.getContext('2d');

let isDrawing = false;
let lastX = 0;
let lastY = 0;
function startDrawing(e) {
    isDrawing = true;
    [lastX, lastY] = [e.offsetX, e.offsetY];
    console.log(e.offsetX, e.offsetY);
}
function draw(e) {
    if (!isDrawing) return;
    context.beginPath();
    context.moveTo(lastX, lastY);
    context.lineTo(e.offsetX, e.offsetY);
    context.strokeStyle = penColor;
    context.lineWidth = 2;
    dc.send(JSON.stringify({ xCoor: e.offsetX, yCoor: e.offsetY, lx: lastX, ly: lastY ,color:penColor}));
    console.log({ xCoor: e.offsetX, yCoor: e.offsetY, lx: lastX, ly: lastY ,color:penColor});
    context.stroke();
    [lastX, lastY] = [e.offsetX, e.offsetY];
}

function stopDrawing() {
    isDrawing = false;
}

canvas.addEventListener('mousedown', startDrawing);
canvas.addEventListener('mousemove', draw);
canvas.addEventListener('mouseup', stopDrawing);
canvas.addEventListener('mouseout', stopDrawing);


